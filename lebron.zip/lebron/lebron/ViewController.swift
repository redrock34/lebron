
    import UIKit
    import CoreData

    class ViewController: UIViewController {
    
    
    let appDelegate = UIApplication.shared.delegate as! AppDelegate
    
    lazy var context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let newUser = User(context: context)

        newUser.pic = #imageLiteral(resourceName: "Jessica").jpegData(compressionQuality: 0.9) as NSObject? as! Data
        
        let object = User(context: context)   //create object of type MyEntity
        object.pic = newUser                         //add image to object

        do {
            try context.save()                   //save object to CoreData
        } catch let error as NSError {
            print("\(error), \(error.userInfo)")
        }
        
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "User")
        
        do {
            
            let jake =   try context.count(for: fetchRequest)
            
            print("d",jake)
            
        } catch let error as NSError {
            print("Could not fetch \(error) ")
        }
        
        
    }
        }
